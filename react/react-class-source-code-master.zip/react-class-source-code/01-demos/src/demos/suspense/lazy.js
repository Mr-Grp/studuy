import React from 'react'

export default () => <p>Lazy Comp</p>
