'use strict';

module.exports = require('./unstable-fizz.node');
